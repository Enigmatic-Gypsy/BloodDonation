from django.apps import AppConfig


class DoctorConfig(AppConfig):
    name = 'Doctor'
