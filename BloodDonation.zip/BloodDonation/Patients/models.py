from django.db import models
from Users.models import Doctors
# Create your models here.

BLOODGROUP = (
	('A+', 'A+'), 
	('B+', 'B+'), 
	('AB+', 'AB+'), 
	('O+', 'O+'), 
	('A-', 'A-'), 
	('B-', 'B-'), 
	('AB-','AB-'), 
	('O-','O-')
	)


class Patients(models.Model):
	PatientID = models.CharField(max_length=15, primary_key=True)
	Vol = models.IntegerField()
	Blood_Type = models.CharField(max_length=3, choices=BLOODGROUP)
	Hospital = models.CharField(max_length=30)
	DocName = models.CharField(max_length=30)