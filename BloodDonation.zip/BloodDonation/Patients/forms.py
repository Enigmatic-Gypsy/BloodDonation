from django.forms import ModelForm
from django import forms
from .models import *

class PatientsForm(ModelForm):
	class Meta:
		model = Patients
		fields = '__all__'
		exclude = ['DocName']