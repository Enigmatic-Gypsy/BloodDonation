from django.shortcuts import render
from django.views.generic import ListView, CreateView
from .models import *
from .forms import *
# Create your views here.

class EnterPatientInfoView(CreateView):
	model = Patients
	template_name = 'profile/enter_patient_info.html'	
	form_class = PatientsForm

	def get_success_url(self):
		return reverse('Bloods')
class PatientsListView(ListView):

    model = Patients
    template_name = "profile/Blood_Usage.html"
    hospital = None
''' if request.user.is_authenticated:
    	user = request.user.hospital
    def get_queryset(self):
    	return Doctors.objects.filter(request.user.hospital)
    #name to be used in the template
    context_object_name = "patient_profile"'''
