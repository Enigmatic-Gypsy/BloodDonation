from django.shortcuts import render
from django.views.generic.base import *
from django.shortcuts import render
from django.views.generic.base import *
from django.contrib import messages
from django.contrib.auth import login, authenticate, REDIRECT_FIELD_NAME
from django.contrib.auth.tokens import default_token_generator
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.views import (
    LogoutView as BaseLogoutView, PasswordChangeView as BasePasswordChangeView,
    PasswordResetDoneView as BasePasswordResetDoneView, PasswordResetConfirmView as BasePasswordResetConfirmView,
)
from django.shortcuts import get_object_or_404, redirect
from django.utils.crypto import get_random_string
from django.utils.decorators import method_decorator
from django.utils.http import is_safe_url
from django.utils.encoding import force_bytes
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator

from django.utils.encoding import force_bytes
from django.utils.http import urlsafe_base64_encode
from django.utils.translation import gettext_lazy as _
from django.views.decorators.cache import never_cache
from django.views.decorators.csrf import csrf_protect
from django.views.decorators.debug import sensitive_post_parameters
from django.views.generic import View, FormView, ListView, CreateView, TemplateView, UpdateView, DeleteView
from django.conf import settings
from django.contrib.auth.models import User
from .models import *
from .forms import *
from django.contrib.admin.views.decorators import staff_member_required
from django.http import HttpRequest
from django.urls import reverse_lazy
from django.db.models import F
from .helper import *
from django.forms import ValidationError
# Create your views here.
   
@method_decorator(login_required, name='dispatch')
class SuccessView(TemplateView):
	template_name = 'datas/success_data.html'



@method_decorator(login_required, name='dispatch')

@method_decorator(staff_member_required, name='dispatch')

class EnterDataView(CreateView):
	model = Donor
	template_name = 'datas/enter_data.html'	
	form_class = DonorForm

	def get_success_url(self):
		return reverse('Tables')

@method_decorator(login_required, name='dispatch')

@method_decorator(staff_member_required, name='dispatch')

class EnterHospitalView(CreateView):
	model = Hospitals
	template_name = 'datas/enter_hospital.html'
	form_class = HospitalsForm

	def get_success_url(self):
		return reverse('Tables') 

@method_decorator(login_required, name='dispatch')
@method_decorator(staff_member_required, name='dispatch')
class ScreeningView(CreateView):
	model = Screening
	template_name = 'datas/screening.html'
	form_class = ScreeningForm

	def clean(self):
		super(ScreeningView, self).clean()
		vol = self.cleaned_data.get('Vol')
		if vol < 0:
			raise ValidationError("Too low.")
		else:
			Type = self.cleaned_data.get('BloodGroup')
			UpdateBloodStat.CalculateBlood(Type, vol)
    

	def get_success_url(self):
		return reverse('Tables')

	

@method_decorator(login_required, name='dispatch')
@method_decorator(staff_member_required, name='dispatch')
class DistributionView(CreateView):
	model = Distribution
	template_name = 'datas/distribution.html'
	form_class = DistributionForm

	def clean(self):
		super(DistributionView, self).clean()
		AP = self.cleaned_data.get('A_p')
		if AP < 0:
			raise ValidationError("It must be positive number.")
		AN = self.cleaned_data.get('A_n')
		if AN < 0:
			raise ValidationError("It must be positive number.")
		BP = self.cleaned_data.get('B_p')
		if BP < 0:
			raise ValidationError("It must be positive number.")
		BN = self.cleaned_data.get('B_n')
		if BN < 0:
			raise ValidationError("It must be positive number.")
		ABP = self.cleaned_data.get('AB_p')
		if ABP < 0:
			raise ValidationError("It must be positive number.")
		ABN = self.cleaned_data.get('AB_n')
		if ABN < 0:
			raise ValidationError("It must be positive number.")
		OP = self.cleaned_data.get('O_p')
		if OP < 0:
			raise ValidationError("It must be positive number.")
		ON = self.cleaned_data.get('O_n')
		if ON < 0:
			raise ValidationError("It must be positive number.")
		Hospital = self.cleaned_data.get('HospitalName')
		UpdateBloodStat.CalculateDistribution(AP,AN,BP,BN,ABP,ABN,OP,ON, Hospital)

	def get_success_url(self):
		return reverse('Tables')

@method_decorator(login_required, name='dispatch')
@method_decorator(staff_member_required, name='dispatch')
class DiscardView(CreateView):
	model = Discard
	template_name = 'datas/discard.html'
	form_class = DiscardForm

	def get_success_url(self):
		return reverse('Tables')

@method_decorator(login_required, name='dispatch')
@method_decorator(staff_member_required, name='dispatch')
class BloodView(ListView):
	model = Blood
	template_name = 'data/Bloods.html'
	context_object_name = "lists"

@method_decorator(staff_member_required, name='dispatch')

@method_decorator(login_required, name='dispatch')
class DiscardListView(ListView):
	
	model = Discard
	template_name = "datas/tables/discard-list.html"
	#name to be used in the template
	context_object_name = "lists"

@method_decorator(login_required, name='dispatch')
@method_decorator(staff_member_required, name='dispatch')
class DistributionListView(ListView):
	
	model = Distribution
	template_name = "datas/tables/distribution-list.html"
	#name to be used in the template
	context_object_name = "lists"

@method_decorator(login_required, name='dispatch')
@method_decorator(staff_member_required, name='dispatch')
class DonorListView(ListView):
	
	model = Donor
	template_name = "datas/tables/donor-list.html"
	#name to be used in the template
	context_object_name = "lists"

@method_decorator(login_required, name='dispatch')
@method_decorator(staff_member_required, name='dispatch')
class HospitalListView(ListView):
	
	model = Hospitals
	template_name = "datas/tables/hospital-list.html"
	#name to be used in the template
	context_object_name = "lists"

@method_decorator(login_required, name='dispatch')
@method_decorator(staff_member_required, name='dispatch')
class ScreeningListView(ListView):
	
	model = Screening
	template_name = "datas/tables/screening-list.html"
	#name to be used in the template
	context_object_name = "lists"

@method_decorator(login_required, name='dispatch')
@method_decorator(staff_member_required, name='dispatch')
class UserListView(ListView):
	
	model = User
	template_name = "datas/tables/user-list.html"
	#name to be used in the template
	context_object_name = "lists"

@method_decorator(login_required, name='dispatch')
@method_decorator(staff_member_required, name='dispatch')
class UpdateDataView(UpdateView):
	model = Donor
	template_name = "data/update_data.html"
	context_object_name = "data"
	success_url = reverse_lazy("Tables")

@method_decorator(login_required, name='dispatch')
@method_decorator(staff_member_required, name='dispatch')
class UpdateHospitalView(UpdateView):
	model = Donor
	template_name = "data/update_hospital.html"
	context_object_name = "data"
	success_url = reverse_lazy("ListHospitals")
@method_decorator(login_required, name='dispatch')
@method_decorator(staff_member_required, name='dispatch')
class UpdateScreeningView(UpdateView):
	model = Screening
	template_name = "data/update_screening.html"
	
	success_url = reverse_lazy("ListScreened")
@method_decorator(login_required, name='dispatch')
@method_decorator(staff_member_required, name='dispatch')
class UpdateDistributionView(UpdateView):
	model = Distribution
	template_name = "data/update_distribution.html"
	context_object_name = "data"
	success_url = reverse_lazy("ListDistribution")
@method_decorator(login_required, name='dispatch')
@method_decorator(staff_member_required, name='dispatch')
class UpdateDiscardView(UpdateView):
	model = Discard
	template_name = "data/update_discard.html"
	context_object_name = "data"
	success_url = reverse_lazy("ListDiscard")
@method_decorator(login_required, name='dispatch')
@method_decorator(staff_member_required, name='dispatch')
class DeleteDataView(DeleteView):
	model = Donor
	template_name = "data/delete_data.html"
	
	success_url = reverse_lazy("Tables")

@method_decorator(login_required, name='dispatch')
@method_decorator(staff_member_required, name='dispatch')
class DeleteHospitalView(DeleteView):
	model = Hospitals
	template_name = "data/delete_hospital.html"

	success_url = reverse_lazy("ListHospitals")
@method_decorator(login_required, name='dispatch')
@method_decorator(staff_member_required, name='dispatch')
class DeleteScreeningView(DeleteView):
	model = Screening
	template_name = "data/delete_screen.html"
	
	success_url = reverse_lazy("ListScreened")
@method_decorator(login_required, name='dispatch')
@method_decorator(staff_member_required, name='dispatch')
class DeleteDistributionView(DeleteView):
	model = Distribution
	template_name = "data/delete_distribution.html"
	
	success_url = reverse_lazy("ListDistribution")



