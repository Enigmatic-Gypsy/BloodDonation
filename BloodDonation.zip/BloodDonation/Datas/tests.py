from django.test import TestCase
from django.test.client import Client
from django.test.client import RequestFactory
from Datas.views import TableListView

# Create your tests here.

class TableListViewTests(TestCase):

	def test_tables_in_the_context(self):

		client = Client()
		response = client.get('/')

		self.assertEquals(list(response.context['object_list']),[])

		User.objects.create(first_name='foo', last_name='bar')
		response = client.get('/')
		self.assertEquals(response.context['object_list'].count(), 1)

	def test_tables_in_the_context_request_factory(self):

		factory = RequestFactory()
		request = factory.get('/')

		response = TableListView.as_view()(request)

		self.assertEquals(list(response.context_data['object_list']), [])

		User.objects.create(first_name='foo', last_name='bar')
		response = TableListView.as_view()(request)
		self.assertEquals(response.context_data['object_list'].count(), 1)