from .models import *
from django.db.models import F
from django.forms import ValidationError
from django.db import transaction
class UpdateBloodStat:
	def CalculateBlood(Type, vol,):
		
			B = Blood.objects.all()[0]
			if Type == 'A+':
				B.A_p+=vol
				B.save()
			if Type == 'A-':
				B.A_n+=vol
				B.save()
			if Type == 'B+':
				B.B_p+=vol
				B.save()
			if Type == 'B-':
				B.B_n+=vol
				B.save()
			if Type == 'AB+':
				B.AB_p+=vol
				B.save()
			if Type == 'AB-':
				B.AB_n+=vol
				B.save()
			if Type == 'O+':
				B.O_p+=vol
				B.save()
			if Type == 'O-':
				B.O_n+=vol
				B.save()
			total = 0
			total+=vol
	
			return total
	@transaction.atomic 
	def CalculateDistribution(A_p, A_n, B_p, B_n, AB_p, AB_n, O_p, O_n, name):
		B = Blood.objects.all()[0]
		BH = Blood_Hospital.objects.get(HospitalName=name)
		if A_p > 0 and A_p < B.A_p:
			B.A_p-=A_p
			B.save()
			BH.A_p+=A_p
			BH.save()
		elif not ( A_p > 0 and A_p < B.A_p):
			raise ValidationError("There is only "+B.A_p+" volume for A+") 
		if A_n > 0 and A_n < B.A_n:
			B.A_n-=A_n
			B.save()
			BH.A_n+=A_n
			BH.save()
		elif not (A_n > 0 and A_n < B.A_n):
			raise ValidationError("There is only "+B.A_n+" volume for A-")
		if B_p > 0 and B_p < B.B_p:
			B.B_p-=B_p
			B.save()
			BH.B_p+=B_p
			BH.save()
		elif not (B_p > 0 and B_p < B.B_p):
			raise ValidationError("There is only "+B.B_p+" volume for B+")
		if B_n > 0 and B_n < B.B_n:
			B.B_n-=B_n
			B.save()
			BH.B_n+=B_n
			BH.save()
		elif not (B_n > 0 and B_n < B.B_n):
			raise ValidationError("There is only "+B.B_n+" volume for B-")
		if AB_p > 0 and AB_p < B.AB_p:
			B.AB_p-=AB_p
			B.save()
			BH.AB_p+=AB_p
			BH.save()
		elif not (AB_p > 0 and AB_p < B.AB_p):
			raise ValidationError("There is only "+B.AB_p+" volume for AB+")
		if AB_n > 0 and AB_n < B.AB_p:
			B.AB_n-=AB_n
			B.save()
			BH.AB_n+=AB_n
			BH.save()
		elif not ( AB_n > 0 and AB_n < B.AB_p):
			raise ValidationError("There is only "+B.AB_n+" volume for AB-")
		if O_p > 0 and O_p < B.O_p:
			B.O_p-=O_p
			B.save()
			BH.O_p+=O_p
		elif not (AB_n > 0 and AB_n < B.AB_p): 
			raise ValidationError("There is only "+B.O_p+" volume for O+")
		if O_n > 0 and O_n < B.O_n:
			B.O_n-=O_n
			B.save()
			BH.O_n+=O_n
			BH.save()
		elif not ( O_n > 0 and O_n < B.O_n):
			raise ValidationError("There is only "+B.O_n+" volume for O-")
