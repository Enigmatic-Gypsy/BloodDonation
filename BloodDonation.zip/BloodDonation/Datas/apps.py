from django.apps import AppConfig


class DatasConfig(AppConfig):
    name = 'Datas'
