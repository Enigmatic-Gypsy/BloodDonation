from django.db import models
from django.forms import ModelForm

# Create your models here.

OCCUPATION_CHOICES = (
	('Teacher', 'Teacher'), 
	('Student','Student'),
	('Engineer','Engineer'),
	('Doctor', 'Doctor')
	)
REGION_CHOICES = (
	('Tigray','Tigray'), 
	('Debub','Debub'), 
	('Oromiya','Oromiya'), 
	('A.A','Addis Ababa'), 
	('Amahar','Amhara'), 
	('Dire Dawa','Dire Dawa')
	)
SEX_CHOICES = (
	('M','Male'), 
	('F','Female')
	)
BLOODGROUP = (
	('A+', 'A+'), 
	('B+', 'B+'), 
	('AB+', 'AB+'), 
	('O+', 'O+'), 
	('A-', 'A-'), 
	('B-', 'B-'), 
	('AB-','AB-'), 
	('O-','O-')
	)
DONTYPE = (
	('Cener', 'Center'), 
	('Mobile', 'Mobile')
	)

HOSP_TYPE = (
	('Private', 'Private'),
	('Public', 'Public'),
	('Referal', 'Referal')
	)
BOOL_CHOICE = (
	('Yes', 'Yes'),
	('No', 'No')
	)
class Hospitals(models.Model):
	HospitalName = models.CharField(max_length=30, primary_key=True)
	Type = models.CharField(max_length=15, choices=HOSP_TYPE)
	Blood_Vol = models.IntegerField()


class Donor(models.Model):
	
	regno = models.CharField(primary_key=True,max_length=15)
	firstName = models.CharField(max_length=55)
	middleName = models.CharField(max_length=55)
	lastName = models.CharField(max_length=55)
	Age = models.IntegerField()
	Sex = models.CharField(max_length=6, choices = SEX_CHOICES)
	Occupation = models.CharField(max_length=15, choices = OCCUPATION_CHOICES)
	Region = models.CharField(max_length=15, choices=REGION_CHOICES)
	City = models.CharField(max_length=15)
	Tel = models.IntegerField()
	Address = models.CharField(max_length=20)
	Birth_Date = models.DateTimeField()
	Remark = models.CharField(max_length=15)
	SubCity = models.CharField(max_length=30)
	Kebele = models.CharField(max_length=10)
	HNo = models.IntegerField()
	Data_Entry_Date = models.DateTimeField(auto_now_add=True)

class Screening(models.Model):
	packNo = models.IntegerField()
	regno =  models.ForeignKey(Donor, on_delete=models.CASCADE)
	Date = models.DateTimeField()
	Weight = models.IntegerField()
	BP = models.CharField(max_length=6)
	Hct = models.CharField(max_length=3, choices=BOOL_CHOICE)
	Vol = models.IntegerField()
	ScreenBy = models.CharField(max_length=55)
	BloodGroup = models.CharField(max_length=3, choices=BLOODGROUP)
	ComponentRequest = models.CharField(max_length=10)
	DonationType = models.CharField(max_length=10, choices=DONTYPE)
	Site = models.CharField(max_length=15)
	CurrentStatus = models.CharField(max_length=55)
	Data_Entry_Date = models.DateTimeField(auto_now_add=True)
	Month = models.IntegerField()

class Distribution(models.Model):
	RecNo = models.IntegerField(primary_key=True)
	Date = models.DateTimeField()
	RequestedUnit = models.IntegerField()
	DistributedFree = models.CharField(max_length=3, choices=BOOL_CHOICE)
	DistributedRep = models.CharField(max_length=3, choices=BOOL_CHOICE)
	packNo = models.IntegerField()
	Blood_Vol = models.IntegerField()
	ExpDate = models.DateTimeField()
	BloodComp = models.CharField(max_length=10)
	HospitalName = models.ForeignKey(Hospitals, on_delete=models.CASCADE)
	DistributedBy = models.CharField(max_length=10)
	Remark = models.CharField(max_length=10)
	Data_Entry_Date = models.DateTimeField(auto_now_add=True)
	Month = models.IntegerField()
	Total = models.IntegerField()
	A_p = models.IntegerField(blank=True, default=0)
	A_n = models.IntegerField(blank=True, default=0)
	B_p = models.IntegerField(blank=True, default=0)
	B_n = models.IntegerField(blank=True, default=0)
	AB_p= models.IntegerField(blank=True, default=0)
	AB_n=models.IntegerField(blank=True, default=0)
	O_p= models.IntegerField(blank=True, default=0)
	O_n=models.IntegerField(blank=True, default=0)

	
class Discard(models.Model):
	RecNo = models.ForeignKey(Distribution, on_delete=models.CASCADE)
	packNo = models.IntegerField()
	Date = models.DateTimeField()
	BloodComp = models.CharField(max_length=10)
	BloodGroup = models.CharField(max_length=3, choices=BLOODGROUP)
	SmallUnit = models.CharField(max_length=3, choices=BOOL_CHOICE)
	Expired = models.CharField(max_length=3, choices=BOOL_CHOICE)
	LabAccident = models.CharField(max_length=3, choices=BOOL_CHOICE)
	Hemolized = models.CharField(max_length=3, choices=BOOL_CHOICE)
	Clotted = models.CharField(max_length=3, choices=BOOL_CHOICE)
	Others = models.CharField(max_length=15)
	Remark = models.CharField(max_length=55)
	Month = models.IntegerField()

class Blood(models.Model):
	Total = models.IntegerField(blank=True, default=0)
	A_p = models.IntegerField(blank=True, default=0)
	A_n = models.IntegerField(blank=True, default=0)
	B_p = models.IntegerField(blank=True, default=0)
	B_n = models.IntegerField(blank=True, default=0)
	AB_p= models.IntegerField(blank=True, default=0)
	AB_n=models.IntegerField(blank=True, default=0)
	O_p= models.IntegerField(blank=True, default=0)
	O_n=models.IntegerField(blank=True, default=0)

class Blood_Hospital(models.Model):
	Total = models.IntegerField(blank=True, default=0)
	A_p = models.IntegerField(blank=True, default=0)
	A_n = models.IntegerField(blank=True, default=0)
	B_p = models.IntegerField(blank=True, default=0)
	B_n = models.IntegerField(blank=True, default=0)
	AB_p= models.IntegerField(blank=True, default=0)
	AB_n=models.IntegerField(blank=True, default=0)
	O_p= models.IntegerField(blank=True, default=0)
	O_n=models.IntegerField(blank=True, default=0)

		