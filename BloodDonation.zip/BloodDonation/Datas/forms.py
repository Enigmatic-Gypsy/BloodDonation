from django.forms import ModelForm
from django import forms
from .models import *

class DonorForm(ModelForm):
	class Meta:
		model = Donor
		fields = '__all__'

	
		
class ScreeningForm(ModelForm):
	class Meta:
		model = Screening
		fields = '__all__'
		
class DistributionForm(ModelForm):
	class Meta:
		model = Distribution
		fields = '__all__'
		
class DiscardForm(ModelForm):
	class Meta:
		model = Discard
		fields = '__all__'
class HospitalsForm(ModelForm):
	class Meta:
		model = Hospitals
		fields = '__all__'

