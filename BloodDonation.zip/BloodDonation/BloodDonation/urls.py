"""BloodDonation URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include, re_path
from django.conf.urls.static import static
from django.conf import settings
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
import Users.views
import Datas.views
import Patients.views
from django.contrib.auth.models import User

app_name = 'Datas'
urlpatterns = [
    path('admin/', admin.site.urls),
    path('accounts/index', Users.views.Index.as_view(), name='Index' ),
    path('accounts/login', Users.views.LogInView.as_view(), name='Login'),
    path('accounts/register', Users.views.RegisterView.as_view(), name='Register'),
    path('accounts/forgot-password', Users.views.forgotPassword.as_view(), name='forgotPassword'),
    path('accounts/doctor_register', Users.views.DoctorsRegisterView.as_view(), name='DocRegister'),
    path('accounts/doctors', Users.views.DoctorsView.as_view(), name='Doctors'),
    path('accounts/user_update/<pk>/', Users.views.UserUpdate.as_view(), name='UserUpdate'),
    path("datas/tables/donor-list", Datas.views.DonorListView.as_view(), name='Tables'),
    path('accounts/logout', Users.views.LogOutView.as_view(), name='Logout'),
    path('datas/enter_data', Datas.views.EnterDataView.as_view(), name='EnterData'),
    path('datas/enter_hospital',Datas.views.EnterHospitalView.as_view(), name='EnterHospital'),
    path('datas/screening', Datas.views.ScreeningView.as_view(), name="Screening"),
    path('datas/distribution', Datas.views.DistributionView.as_view(), name='Distribution'),
    path('datas/discard', Datas.views.DiscardView.as_view(), name='Discard'),
    path('datas/success_data', Datas.views.SuccessView.as_view(), name='Success'),
    path('datas/Bloods', Datas.views.BloodView.as_view(), name='Bloods'),
    path('datas/update_screen/<pk>/', Datas.views.UpdateScreeningView.as_view(), name='UpdateScreen'),
    path('datas/update_distribution/<pk>/', Datas.views.UpdateDistributionView.as_view(), name='UpdateDistribution'),
    path('datas/Bloods', Datas.views.UpdateDiscardView.as_view(), name='UpdateDiscard'),
    path('datas/delete_data/<pk>/', Datas.views.DeleteDataView.as_view(), name='DeleteData'),
    path('datas/update_data/<slug:slug>/', Datas.views.UpdateDataView.as_view(), name='UpdateData'),
    path('datas/delete_screen/<pk>/', Datas.views.DeleteScreeningView.as_view(), name='DeleteScreen'),
    path('datas/delete_distribution/<pk>', Datas.views.DeleteDistributionView.as_view(), name='DeleteDistribution'),
    path('datas/delete_hospital/<pk>', Datas.views.DeleteHospitalView.as_view(), name='DeleteHospital'),
    path('datas/tables/discard-list', Datas.views.DiscardListView.as_view(), name='ListDiscard'),
    path('datas/tables/distribution-list', Datas.views.DistributionListView.as_view(), name='ListDistribution'),
    path('datas/tables/hospital-list', Datas.views.HospitalListView.as_view(), name='ListHospitals'),
    path('datas/tables/screening-list', Datas.views.ScreeningListView.as_view(), name='ListScreened'),
    path('datas/tables/user-list', Datas.views.UserListView.as_view(), name='UserList'),
    path('profile/Blood_usage', Patients.views.PatientsListView.as_view(), name='PatientList'),
    path('profile/enter_patient_info', Patients.views.EnterPatientInfoView.as_view(), name='PatientInfo'),   
] + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
urlpatterns += staticfiles_urlpatterns()