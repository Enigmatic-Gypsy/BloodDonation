from django.db import models
from django.contrib.auth.models import User
from django.contrib.auth.models import AbstractUser
from django.urls import reverse
#To handle multiple users with different restriction

# Create your models here.

class Activation(models.Model):
 	user = models.ForeignKey(User, on_delete=models.CASCADE)
 	created_at = models.DateTimeField(auto_now_add=True)
 	code = models.CharField(max_length=20, unique=True)
 	email = models.EmailField(blank=True)

 	def get_absolute_url(self):
 		return reverse('UserUpdate', kwargs={'pk': self.pk})

class Doctors(models.Model):
	user = models.ForeignKey(User, on_delete=models.CASCADE)
	first_name = models.CharField(max_length=30)
	last_name = models.CharField(max_length=30)
	password2 = models.CharField(max_length=40)
	password1 = models.CharField(max_length=40)
	email = models.EmailField()
	hospital = models.CharField(max_length=30)


