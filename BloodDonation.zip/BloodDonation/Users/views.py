from django.shortcuts import render
from django.views.generic.base import *
from django.contrib import messages
from django.contrib.auth import login, authenticate, REDIRECT_FIELD_NAME
from django.contrib.auth.tokens import default_token_generator
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.views import (
    LogoutView as BaseLogoutView, PasswordChangeView as BasePasswordChangeView,
    PasswordResetDoneView as BasePasswordResetDoneView, PasswordResetConfirmView as BasePasswordResetConfirmView,
)
from django.shortcuts import get_object_or_404, redirect
from django.utils.crypto import get_random_string
from django.utils.decorators import method_decorator
from django.utils.http import is_safe_url
from django.utils.encoding import force_bytes
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator

from django.utils.encoding import force_bytes
from django.utils.http import urlsafe_base64_encode
from django.utils.translation import gettext_lazy as _
from django.views.decorators.cache import never_cache
from django.views.decorators.csrf import csrf_protect
from django.views.decorators.debug import sensitive_post_parameters
from django.views.generic import View, FormView, CreateView, UpdateView
from django.conf import settings
from django.contrib.admin.views.decorators import staff_member_required
from django.urls import reverse_lazy

from .forms import *
from .models import *


class GuestOnlyView(View):
    def dispatch(self, request, *args, **kwargs):
        # Redirect to the index page if the user already authenticated
        if request.user.is_authenticated:
            return redirect(settings.LOGIN_REDIRECT_URL)

        return super().dispatch(request, *args, **kwargs)
@method_decorator(login_required, name='dispatch')
@method_decorator(staff_member_required, name='dispatch')
class Index(TemplateView):
    
    template_name = 'accounts/index.html'


class LogInView(GuestOnlyView, FormView):
    template_name = 'accounts/login.html'

    @staticmethod
    def get_form_class(**kwargs):
        if settings.DISABLE_USERNAME or settings.LOGIN_VIA_EMAIL:
            return SignInViaEmailForm

        return SignInViaEmailForm

    @method_decorator(sensitive_post_parameters('password'))
    @method_decorator(csrf_protect)
    @method_decorator(never_cache)
    def dispatch(self, request, *args, **kwargs):
        # Sets a test cookie to make cookies enabled
        request.session.set_test_cookie()

        return super().dispatch(request, *args, **kwargs)

    def form_valid(self, form):
        request = self.request

        # If the test cookie worked, delete it
        if request.session.test_cookie_worked():
            request.session.delete_test_cookie()

       
        if settings.USE_REMEMBER_ME:
            if not form.cleaned_data['remember_me']:
                request.session.set_expiry(0)

        login(request, form.user_cache)

        redirect_to = request.POST.get(REDIRECT_FIELD_NAME, request.GET.get(REDIRECT_FIELD_NAME))
        url_is_safe = is_safe_url(redirect_to, allowed_hosts=request.get_host(), require_https=request.is_secure())

        if url_is_safe:
            return redirect(redirect_to)

        return redirect(settings.LOGIN_REDIRECT_URL)



class RegisterView(GuestOnlyView, FormView):

    template_name = 'accounts/register.html'
    form_class = RegisterForm

    def form_valid(self, form):
        request = self.request
        user = form.save(commit=False)

        if settings.DISABLE_USERNAME:
            # Set a temporary username
            user.username = get_random_string()
        else:
            user.username = form.cleaned_data['username']

        if settings.ENABLE_USER_ACTIVATION:
            user.is_active = False

        # Create a user record
        user.is_staff = False
        user.save()

        # Change the username to the "user_ID" form
        if settings.DISABLE_USERNAME:
            user.username = f'user_{user.id}'
            user.save()

           
        
        raw_password = form.cleaned_data['password1']

        user = authenticate(username=user.username, password=raw_password)
        login(request, user)

            

        return redirect('Login')


class forgotPassword(TemplateView):

 	template_name = 'accounts/forgot-password.html'


@method_decorator(login_required, name='dispatch')
class LogOutView(LoginRequiredMixin, BaseLogoutView):
    
    template_name = 'accounts/logout.html'
@method_decorator(login_required, name='dispatch')
#@method_decorator(doctor_required, name='dispatch')
class DoctorsView(TemplateView):
    template_name = 'accounts/doctors.html'

class DoctorsRegisterView(CreateView):
    model = Doctors
    template_name = 'accounts/doctor_register.html'
    form_class = DoctorsForm

class UserUpdate(UpdateView):
    model = User
    fields = '__all__'
    template_name = 'accounts/user_update.html'
    success_url = reverse_lazy("Index")

    def get(self, request, **kwargs):
        self.object = User.objects.get(pk=self.request.user.pk)
        form_class = self.get_form_class()
        form = self.get_form(form_class)
        context = self.get_context_data(object=self.object, form=form)
        return self.render_to_response(context)

    def form_valid(self, form):
        self.object = form.save(commit=False)
        self.object.user = self.request.user
        self.object.save()
        return HttpResponseRedirect(self.get_success_url())
